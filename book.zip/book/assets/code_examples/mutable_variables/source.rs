fn main() {
    let mut x = 5;
    x = 6; //OK
}