fn main() {
    let x = String::from("hello");
    let y = x;
    println!("{}", y)
}
