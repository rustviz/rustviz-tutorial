fn main() {
    let s = String::from("hello");
}