fn main() {
    let six = plus_one(5);
}

fn plus_one(x: i32) -> i32 {
    x + 1
}