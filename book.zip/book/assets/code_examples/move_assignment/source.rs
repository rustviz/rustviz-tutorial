fn main() {
    let x = String::from("hello");
    let mut y = String::from("test");
    y = x;
  }