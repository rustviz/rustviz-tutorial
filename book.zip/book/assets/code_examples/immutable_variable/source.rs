fn main() {
    let x = 5;
}